"""E2E: navegación entre coplas en cada ámbito, volver do login á mesma páxina, story para Instagram,
«x» dos buscadores en móbil e ritmos pechados."""
import sys, pathlib, json, urllib.request
sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1] / "harness"))
from common import APP, OUT, sql, Client, fake_login_as, ok, finish
from playwright.sync_api import sync_playwright
import shoot_lib as S

for t in ("follows", "favorites", "profiles", "sessions", "users"):
    sql(f"delete from {t}")
PAR = "par:3601505"  # Estacas (San Fiz): 4 coplas
par_ids = [r[0] for r in sql("select copla_id from copla_territories where territory_id=? order by copla_id", PAR)]
fav = Client("g-fav", "fav@example.com", "Fav")
for cid in par_ids[:2]:
    fav.call("POST", "/api/me/favorites", {"kind": "copla", "ref": str(cid), "on": True})
errs = []


def handler(route):
    return route.continue_() if route.request.url.startswith((APP, "http://localhost:9911")) else S.base_handle(route)


def pager(pg):
    return pg.locator("#coplaDrawer .drawer-pager span").inner_text().strip()


with sync_playwright() as p:
    b = p.chromium.launch()

    def newpage(url="/", vp=None, **kw):
        ctx = b.new_context(viewport=vp or {"width": 1440, "height": 900}, **kw); pg = ctx.new_page()
        pg.on("pageerror", lambda e: errs.append(str(e) + " | " + (e.stack or "")[:1600].replace("\n", " ") + " @" + pg.url))
        pg.route("**/*", handler); pg.goto(APP + url)
        pg.wait_for_selector("#global-loading[hidden]", state="attached", timeout=30000); pg.wait_for_timeout(1500)
        return ctx, pg

    # --- navegación só entre as coplas da listaxe que se amosa
    ctx, pg = newpage(f"/?territory_id={PAR}&view=territory")
    n = pg.locator("#territoryCoplaList [data-open-copla]").count()
    ok("territorio: amosa as súas coplas", n == len(par_ids) == 4, (n, len(par_ids)))
    pg.locator("#territoryCoplaList [data-open-copla]").first.click(position={"x": 12, "y": 12}); pg.wait_for_selector("#coplaDrawer:not([hidden]) .copla-sheet")
    ok("Territorios > coplas: a ficha navega só entre as do territorio", pager(pg) == "1 / 4", pager(pg))
    pg.keyboard.press("ArrowRight"); pg.wait_for_timeout(300)
    ok("→ pasa á seguinte", pager(pg) == "2 / 4", pager(pg))
    for _ in range(5): pg.keyboard.press("ArrowRight"); pg.wait_for_timeout(120)
    ok("…e non pasa da última", pager(pg) == "4 / 4", pager(pg))
    ctx.close()

    ctx, pg = newpage("/?view=territory")
    pg.locator("#territoryCoplaList [data-open-copla]").first.click(position={"x": 12, "y": 12}); pg.wait_for_selector("#coplaDrawer:not([hidden]) .copla-sheet")
    ok("nivel Galiza: navega por todas as coplas (non só as cargadas)", pager(pg).startswith("1 / ") and int(pager(pg).split("/")[1]) > 100, pager(pg))
    ctx.close()

    # swipe táctil (móbil) no mesmo ámbito
    ctx, pg = newpage(f"/?territory_id={PAR}&view=territory", {"width": 390, "height": 844}, has_touch=True, is_mobile=True)
    pg.locator("#territoryCoplaList [data-open-copla]").first.tap(position={"x": 12, "y": 12}); pg.wait_for_selector("#coplaDrawer:not([hidden]) .copla-sheet")
    pg.evaluate("""() => { const el = document.querySelector('#coplaDrawer .copla-sheet'); const mk = (type, x) => { const t = new Touch({identifier: 1, target: el, clientX: x, clientY: 300}); el.dispatchEvent(new TouchEvent(type, {bubbles: true, cancelable: true, touches: type === 'touchend' ? [] : [t], changedTouches: [t]})); }; mk('touchstart', 300); mk('touchend', 120); }""")
    pg.wait_for_timeout(400)
    ok("swipe á esquerda: seguinte copla do territorio", pager(pg) == "2 / 4", pager(pg))
    ctx.close()

    # --- favoritas: navegar só entre as 2 favoritas
    fake_login_as("g-fav", "fav@example.com", "Fav")
    ctx = b.new_context(viewport={"width": 1440, "height": 900}); pg = ctx.new_page(); pg.route("**/*", handler)
    pg.on("pageerror", lambda e: errs.append(str(e) + " | " + (e.stack or "")[:1600].replace("\n", " ") + " @" + pg.url))
    pg.goto(APP + "/api/auth/google?next=/%3Fview%3Dprofile"); pg.wait_for_selector("#global-loading[hidden]", state="attached", timeout=30000); pg.wait_for_timeout(2000)
    ok("perfil: 2 coplas favoritas", pg.locator(".fav-list [data-copla-id]").count() == 2, pg.locator(".fav-list [data-copla-id]").count())
    pg.locator(".fav-list [data-copla-id]").first.click(); pg.wait_for_selector("#coplaDrawer:not([hidden]) .copla-sheet")
    ok("favoritas: a ficha abre sen saír do perfil e navega entre as 2", pager(pg) == "1 / 2" and pg.locator("#view-profile.active").count() == 1, pager(pg))
    pg.keyboard.press("ArrowRight"); pg.wait_for_timeout(300)
    ok("favoritas: → pasa á segunda", pager(pg) == "2 / 2")
    pg.keyboard.press("ArrowRight"); pg.wait_for_timeout(200)
    ok("favoritas: non hai terceira", pager(pg) == "2 / 2")
    ctx.close()

    # --- volver do login á mesma páxina
    fake_login_as("g-back", "back@example.com", "Back")
    ctx, pg = newpage(f"/?territory_id={PAR}&view=territory")
    pg.click('[data-territory-tab="media"]'); pg.wait_for_timeout(400)
    pg.click('[data-territory-tab="coplas"]'); pg.wait_for_timeout(300)
    pg.locator("#territoryCoplaList [data-open-copla]").nth(1).click(position={"x": 12, "y": 12}); pg.wait_for_selector("#coplaDrawer:not([hidden]) .copla-sheet")
    pg.evaluate("document.querySelector('[data-account=\"login\"]').click()")
    pg.wait_for_url(lambda u: u.startswith(APP) and "api/auth" not in u, timeout=30000)
    pg.wait_for_selector("#global-loading[hidden]", state="attached", timeout=30000); pg.wait_for_timeout(2500)
    me = json.loads(pg.evaluate("fetch('/api/auth/me').then(r=>r.text())"))
    ok("login: entrou", bool(me.get("user")), me)
    ok("login: volve á vista de territorio", pg.locator("#view-territory.active").count() == 1 and "Estacas" in pg.locator("#view-territory").inner_text())
    ok("login: e á mesma ficha de copla aberta", pg.locator("#coplaDrawer:not([hidden]) .copla-sheet").count() == 1, pg.locator("#coplaDrawer").inner_text()[:40] if pg.locator("#coplaDrawer").count() else "")
    ok("login: sen restos na URL", "fe_back" not in pg.evaluate("location.href"), pg.evaluate("location.href"))
    ctx.close()
    # hash de autoría (#/privacidade) e outras vistas
    fake_login_as("g-back", "back@example.com", "Back")
    ctx, pg = newpage("/?view=melodies")
    pg.evaluate("document.querySelector('[data-account=\"login\"]').click()")
    pg.wait_for_url(lambda u: u.startswith(APP) and "api/auth" not in u, timeout=30000)
    pg.wait_for_selector("#global-loading[hidden]", state="attached", timeout=30000); pg.wait_for_timeout(2000)
    ok("login: volve a Melodías", pg.locator("#view-melodies.active").count() == 1)
    ctx.close()

    # --- story (móbil)
    ctx, pg = newpage("/?view=coplas", {"width": 390, "height": 844}, has_touch=True, is_mobile=True)
    pg.locator("#coplaList [data-open-copla]").first.tap(position={"x": 12, "y": 12}); pg.wait_for_selector("#coplaDrawer:not([hidden]) .copla-sheet")
    ok("story: botón visible en móbil", pg.locator("[data-share-story]").is_visible())
    pg.locator("[data-share-story]").tap(); pg.wait_for_selector("#storyModal .story-preview img", timeout=15000)
    dims = pg.evaluate("(() => { const i = document.querySelector('#storyModal img'); return [i.naturalWidth, i.naturalHeight]; })()")
    ok("story: imaxe 1080 x 1920", dims == [1080, 1920], dims)
    src1 = pg.evaluate("document.querySelector('#storyModal img').src")
    pg.screenshot(path=str(OUT / "story-modal.png"))
    pg.locator('[data-story-theme="tinta"]').tap(); pg.wait_for_timeout(1800)
    src2 = pg.evaluate("document.querySelector('#storyModal img')?.src")
    ok("story: cambiar de estilo xera outra imaxe", src2 and src2 != src1)
    href = pg.evaluate("document.querySelector('[data-story-download]').href")
    ok("story: descarga dispoñible (blob PNG)", href.startswith("blob:"), href[:20])
    # contido: a imaxe non está en branco (hai píxeles escuros e claros)
    stats = pg.evaluate("""async () => { const i = document.querySelector('#storyModal img'); const c = document.createElement('canvas'); c.width = 108; c.height = 192; const x = c.getContext('2d'); x.drawImage(i, 0, 0, 108, 192); const d = x.getImageData(0, 0, 108, 192).data; const set = new Set(); for (let k = 0; k < d.length; k += 4) set.add((d[k] >> 5) + ',' + (d[k+1] >> 5) + ',' + (d[k+2] >> 5)); return set.size; }""")
    ok("story: a imaxe ten contido (non é lisa)", stats >= 3, stats)
    pg.keyboard.press("Escape"); pg.wait_for_timeout(300)
    ok("story: Esc pecha só o modal", pg.locator("#storyModal").count() == 0 and pg.locator("#coplaDrawer:not([hidden])").count() == 1)
    ctx.close()
    ctx, pg = newpage("/?view=coplas")
    pg.locator("#coplaList [data-open-copla]").first.click(position={"x": 12, "y": 12}); pg.wait_for_selector("#coplaDrawer:not([hidden]) .copla-sheet")
    ok("story: agochado en escritorio", not pg.locator("[data-share-story]").is_visible())
    ctx.close()

    # --- «x» dos buscadores (móbil)
    ctx, pg = newpage("/?view=coplas", {"width": 390, "height": 844}, has_touch=True, is_mobile=True)
    box = pg.locator("#coplaSearch")
    total = pg.locator("#coplaResultCount").inner_text()
    ok("«x»: oculta sen texto", pg.locator(".search-clear:visible").count() == 0)
    box.fill("zzzqq"); pg.wait_for_timeout(500)
    ok("«x»: aparece con texto", pg.locator("#coplaSearch + .search-clear:visible").count() == 1)
    bb = box.bounding_box(); xb = pg.locator("#coplaSearch + .search-clear").bounding_box()
    ok("«x»: dentro do campo, á dereita", bb["x"] < xb["x"] and xb["x"] + xb["width"] <= bb["x"] + bb["width"] + 1 and abs((xb["y"] + xb["height"] / 2) - (bb["y"] + bb["height"] / 2)) < 6, (bb, xb))
    pg.locator("#coplaSearch + .search-clear").tap(); pg.wait_for_timeout(600)
    ok("«x»: borra a busca e refai a lista", box.input_value() == "" and pg.locator("#coplaResultCount").inner_text() == total, (box.input_value(), pg.locator("#coplaResultCount").inner_text(), total))
    ok("«x»: mantén o foco no campo", pg.evaluate("document.activeElement.id") == "coplaSearch")
    pg.click('.mobile-nav [data-view="map"]'); pg.wait_for_timeout(500)
    pg.fill("#mapSearch", "Lira"); pg.wait_for_timeout(500)
    ok("«x» tamén no buscador do mapa", pg.locator("#mapSearch + .search-clear:visible").count() == 1)
    pg.locator("#mapSearch + .search-clear").tap(); pg.wait_for_timeout(400)
    ok("…e limpa os resultados do mapa", pg.input_value("#mapSearch") == "" and not pg.locator("#mapResults").inner_text().strip())
    ctx.close()

    # --- ritmos pechados (guía/admin)
    fake_login_as("g-adm2", "folear3@gmail.com", "Admin")
    ctx = b.new_context(viewport={"width": 1440, "height": 900}); pg = ctx.new_page(); pg.route("**/*", handler)
    pg.goto(APP + "/api/auth/google?next=/%3Fview%3Dmelodies"); pg.wait_for_selector("#global-loading[hidden]", state="attached", timeout=30000); pg.wait_for_timeout(2000)
    pg.click('[data-new-melody=""]'); pg.wait_for_selector("#melodyRhythm")
    tag = pg.evaluate("document.querySelector('#melodyRhythm').tagName")
    opts = pg.evaluate("[...document.querySelectorAll('#melodyRhythm option')].map(o => o.value)")
    ok("melodía: o ritmo é un desplegábel pechado (sen texto libre)", tag == "SELECT" and not pg.locator("input#melodyRhythm").count())
    ok("…con «Cantar popular» e «Canto»", "Canto" in opts and "Cantar popular" in opts and "Xota" in opts and "Muiñeira" in opts, opts)
    pg.click("#saveMelody"); pg.wait_for_timeout(300)
    ok("…e sen ritmo escollido non garda", "Escolle un ritmo" in pg.locator("#melodyFeedback").inner_text(), pg.locator("#melodyFeedback").inner_text())
    ctx.close()
    b.close()

ok("sen erros de JS", not errs, errs[:3])
finish()
