// Botón «x» para borrar toda a busca en calquera <input type="search">, como o do buscador de
// Instagram. Chrome/Safari levan un propio, pero Firefox e os móbiles non: engádese un igual en
// todos (o nativo agóchase por CSS) sen tocar cada pantalla.
//
// O botón créase ao entrar no campo e posiciónase por riba do extremo dereito do input. Móstrase
// só mentres hai texto. Ao premelo vacíase o campo e avísanse os oíntes (`input` e `search`).

const BUTTON_CLASS = "search-clear";
let active = null; // { input, button }

function buttonFor(input) {
  let button = input.nextElementSibling;
  if (button && button.classList.contains(BUTTON_CLASS)) return button;
  button = document.createElement("button");
  button.type = "button";
  button.className = BUTTON_CLASS;
  button.tabIndex = -1;
  button.hidden = true;
  button.setAttribute("aria-label", "Borrar a busca");
  button.innerHTML = '<svg viewBox="0 0 16 16" aria-hidden="true" focusable="false"><path d="M4 4l8 8M12 4l-8 8"/></svg>';
  // O foco non debe saír do campo: así o teclado móbil non se pecha ao borrar.
  button.addEventListener("pointerdown", event => event.preventDefault());
  button.addEventListener("mousedown", event => event.preventDefault());
  button.addEventListener("click", () => {
    const target = button.previousElementSibling;
    if (!(target instanceof HTMLInputElement)) return;
    target.value = "";
    target.dispatchEvent(new Event("input", { bubbles: true }));
    target.dispatchEvent(new Event("search", { bubbles: true }));
    target.focus();
    update(target);
  });
  input.insertAdjacentElement("afterend", button);
  return button;
}

function place(input, button) {
  const size = 26;
  const right = input.offsetLeft + input.offsetWidth;
  button.style.left = `${Math.max(0, right - size - 6)}px`;
  button.style.top = `${input.offsetTop + Math.max(0, (input.offsetHeight - size) / 2)}px`;
}

function update(input) {
  const button = buttonFor(input);
  const show = Boolean(input.value) && document.activeElement === input && !input.disabled && !input.readOnly;
  button.hidden = !show;
  input.classList.toggle("has-clear", show);
  if (show) place(input, button);
  active = { input, button };
}

function isSearch(node) {
  return node instanceof HTMLInputElement && node.type === "search";
}

document.addEventListener("focusin", event => { if (isSearch(event.target)) update(event.target); });
document.addEventListener("input", event => { if (isSearch(event.target)) update(event.target); });
document.addEventListener("focusout", event => {
  if (!isSearch(event.target)) return;
  const button = event.target.nextElementSibling;
  if (button && button.classList.contains(BUTTON_CLASS)) button.hidden = true;
  event.target.classList.remove("has-clear");
  if (active && active.input === event.target) active = null;
});
window.addEventListener("resize", () => { if (active && active.input.isConnected) update(active.input); });
