// Xera unha imaxe vertical (1080 x 1920, o formato das stories de Instagram) cunha copla, ao
// estilo das tarxetas de letra de Spotify: o texto grande e á esquerda, o lugar e a marca abaixo.
// Debúxase nun <canvas> co mesmo isotipo e tipografías do sitio (DM Mono e Inter, autoalojadas).

export const STORY_THEMES = [
  { id: "papel", label: "Papel", bg: "#F7F7F2", ink: "#171717", soft: "#6B6B64", accent: "#C24330" },
  { id: "tinta", label: "Tinta", bg: "#171717", ink: "#F7F7F2", soft: "#A8A8A0", accent: "#E0644F" },
  { id: "ar", label: "Ar", bg: "#C24330", ink: "#F7F7F2", soft: "#F3D5CD", accent: "#F7F7F2" },
];

const WIDTH = 1080;
const HEIGHT = 1920;
const MARGIN = 96;
const TEXT_TOP = 330;
const TEXT_BOTTOM = 1560;
const MONO = '"DM Mono", "IBM Plex Mono", ui-monospace, Consolas, monospace';
const SANS = '"Inter", ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif';

async function loadFonts() {
  if (!document.fonts?.load) return;
  try {
    await Promise.all([
      document.fonts.load(`500 48px "DM Mono"`),
      document.fonts.load(`400 32px "DM Mono"`),
      document.fonts.load(`500 32px "Inter"`),
    ]);
  } catch {
    // Sen as tipografías propias cae á monoespaciada do sistema.
  }
}

// Parte unha liña en varias para que caiba no ancho dado (por palabras; unha palabra moi longa parte por caracteres).
function wrapLine(ctx, line, maxWidth) {
  if (ctx.measureText(line).width <= maxWidth) return [line];
  const out = [];
  let current = "";
  for (const word of line.split(/\s+/)) {
    const attempt = current ? `${current} ${word}` : word;
    if (ctx.measureText(attempt).width <= maxWidth) { current = attempt; continue; }
    if (current) out.push(current);
    if (ctx.measureText(word).width <= maxWidth) { current = word; continue; }
    let piece = "";
    for (const char of word) {
      if (ctx.measureText(piece + char).width > maxWidth) { out.push(piece); piece = char; } else piece += char;
    }
    current = piece;
  }
  if (current) out.push(current);
  return out;
}

// Atopa o tamaño de letra máis grande (ata 66 px) co que o texto cabe na caixa.
export function layoutStoryText(ctx, text, maxWidth, maxHeight) {
  const verses = String(text || "").replace(/\r/g, "").split("\n").map(line => line.trim());
  for (let size = 66; size >= 24; size -= 2) {
    ctx.font = `500 ${size}px ${MONO}`;
    const lineHeight = Math.round(size * 1.42);
    const lines = [];
    verses.forEach(verse => {
      if (!verse) { lines.push(null); return; }
      wrapLine(ctx, verse, maxWidth).forEach(part => lines.push(part));
    });
    const height = lines.reduce((sum, line) => sum + (line === null ? lineHeight * 0.5 : lineHeight), 0);
    if (height <= maxHeight || size === 24) return { size, lineHeight, lines, height };
  }
  return null;
}

function drawIsotipo(ctx, x, y, size, color, dot) {
  const scale = size / 48; // o isotipo vive nunha retícula de 48 de alto (viewBox 8 9 48 50)
  ctx.save();
  ctx.translate(x - 8 * scale, y - 9 * scale);
  ctx.scale(scale, scale);
  ctx.lineWidth = 6;
  ctx.lineCap = "round";
  ctx.strokeStyle = color;
  ctx.stroke(new Path2D("M50.79 27.16A20 20 0 1 1 38.84 15.21"));
  ctx.fillStyle = dot;
  ctx.beginPath();
  ctx.arc(51.1, 14.9, 4.2, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
}

export async function renderCoplaStory({ text, place = "", themeId = "papel" } = {}) {
  await loadFonts();
  const theme = STORY_THEMES.find(item => item.id === themeId) || STORY_THEMES[0];
  const canvas = document.createElement("canvas");
  canvas.width = WIDTH;
  canvas.height = HEIGHT;
  const ctx = canvas.getContext("2d");
  ctx.fillStyle = theme.bg;
  ctx.fillRect(0, 0, WIDTH, HEIGHT);

  // Cabeceira: isotipo + «fol e ar»
  drawIsotipo(ctx, MARGIN, 150, 76, theme.ink, theme.accent);
  ctx.fillStyle = theme.ink;
  ctx.textBaseline = "middle";
  ctx.font = `400 48px ${MONO}`;
  ctx.fillText("fol e ar", MARGIN + 104, 178);

  // Copla: bloque centrado en vertical dentro da caixa de texto, aliñado á esquerda
  const box = layoutStoryText(ctx, text, WIDTH - MARGIN * 2, TEXT_BOTTOM - TEXT_TOP);
  ctx.textBaseline = "alphabetic";
  if (box) {
    ctx.font = `500 ${box.size}px ${MONO}`;
    ctx.fillStyle = theme.ink;
    let y = TEXT_TOP + Math.max(0, (TEXT_BOTTOM - TEXT_TOP - box.height) / 2) + box.size;
    box.lines.forEach(line => {
      if (line === null) { y += box.lineHeight * 0.5; return; }
      ctx.fillText(line, MARGIN, y);
      y += box.lineHeight;
    });
  }

  // Pé: lugar e enderezo
  ctx.fillStyle = theme.accent;
  ctx.fillRect(MARGIN, 1660, 72, 6);
  ctx.fillStyle = theme.ink;
  ctx.textBaseline = "alphabetic";
  ctx.font = `500 40px ${SANS}`;
  const placeLines = wrapLine(ctx, place || "Galiza", WIDTH - MARGIN * 2).slice(0, 2);
  placeLines.forEach((line, index) => ctx.fillText(line, MARGIN, 1728 + index * 52));
  ctx.fillStyle = theme.soft;
  ctx.font = `400 34px ${MONO}`;
  ctx.fillText("folear.gal", MARGIN, 1728 + placeLines.length * 52 + 18);

  return new Promise((resolve, reject) => {
    canvas.toBlob(blob => (blob ? resolve(blob) : reject(new Error("Non se puido xerar a imaxe."))), "image/png");
  });
}

export function canShareFile(blob) {
  try {
    const file = new File([blob], "fol-e-ar.png", { type: "image/png" });
    return Boolean(navigator.canShare && navigator.canShare({ files: [file] }) && navigator.share);
  } catch {
    return false;
  }
}

export async function shareStory(blob, name) {
  const file = new File([blob], name, { type: "image/png" });
  await navigator.share({ files: [file], title: "Fol e ar" });
}
